# VSay Shell CLI

A command-line tool for connecting to and managing your VSay remote machines.

## Features

- 🔐 Secure login with a personal API key (no password)
- 📋 List all your registered machines
- 🖥️ Connect to machines via WebSocket terminal
- 🗑️ Delete machines from your account
- 🌍 Cross-platform support (Linux, macOS, Windows)

## Installation

### Using Package Manager

**macOS (Homebrew):**
```bash
brew tap vsay/tap
brew install vsay-shell-cli
```

**Linux (Debian/Ubuntu):**
```bash
# Download the .deb package from releases
sudo dpkg -i vsay-shell-cli_*.deb
```

**Linux (RHEL/CentOS/Fedora):**
```bash
# Download the .rpm package from releases
sudo rpm -i vsay-shell-cli_*.rpm
```

**Windows (Scoop):**
```powershell
scoop bucket add vsay https://github.com/vsay/scoop-bucket
scoop install vsay-shell-cli
```

### Manual Installation

Download the binary for your platform from the [Releases](https://github.com/vsay/vsay-shell-cli/releases) page.

**Linux/macOS:**
```bash
# Download and extract
tar -xzf vsay-shell-cli_*_linux_amd64.tar.gz

# Move to PATH
sudo mv vsay-shell-cli /usr/local/bin/

# Make executable
sudo chmod +x /usr/local/bin/vsay-shell-cli
```

**Windows:**
1. Download the `.zip` file
2. Extract to a folder
3. Add the folder to your PATH

### Build from Source

```bash
# Clone the repository
git clone https://github.com/vsay/vsay-shell-cli.git
cd vsay-shell-cli

# Build
make build

# Install
make install
```

## Usage

### Login

```bash
vsay-shell-cli login https://api.vsay.com
```

You will be prompted for your **personal API key** (generate one from the web UI
under Settings > API Keys — max 5 per user). You can also pass it non-interactively:

```bash
vsay-shell-cli login https://api.vsay.com --api-key vsay_xxxxxxxxxxxxxxxx
```

### List Machines

```bash
vsay-shell-cli list
# or
vsay-shell-cli ls
```

Output:
```
ℹ Fetching machines...

Machines (3)
─────────────────────────────────────────

Name           Status      IP Address      OS                    Last Seen
my-server      ● Online    192.168.1.10    Ubuntu 22.04 LTS      2 minutes ago
dev-machine    ● Online    10.0.0.5        Debian 12             5 minutes ago
backup-srv     ○ Offline   172.16.0.100    CentOS 8              2 hours ago

ℹ 2 online, 3 total
ℹ Connect using: vsay-shell-cli connect <machine-name>
```

### Connect to Machine

```bash
vsay-shell-cli connect my-server
```

This opens an interactive terminal session with the remote machine.

### Delete Machine

```bash
# With confirmation prompt
vsay-shell-cli delete my-server

# Skip confirmation
vsay-shell-cli delete my-server --force
# or
vsay-shell-cli rm my-server -f
```

### Check Status

```bash
vsay-shell-cli status
```

### Logout

```bash
vsay-shell-cli logout
```

### Version

```bash
vsay-shell-cli version
```

## Configuration

Configuration is stored in `~/.vsay-shell-cli/config.json`:

```json
{
  "api_url": "https://api.vsay.com",
  "token": "vsay_xxxxxxxxxxxxxxxx",
  "email": "user@example.com",
  "logged_in": true
}
```

## Commands Reference

| Command | Description |
|---------|-------------|
| `login <URL>` | Login to VSay server |
| `logout` | Logout from current session |
| `status` | Show login status |
| `list`, `ls` | List all machines |
| `connect <name>` | Connect to a machine |
| `delete <name>`, `rm` | Delete a machine |
| `version` | Show version info |
| `help` | Show help |

## Building

### Requirements

- Go 1.21+
- Make

### Build Commands

```bash
# Build for current platform
make build

# Build for all platforms
make build-all

# Build for specific platform
make build-linux
make build-darwin
make build-windows

# Create release packages
make release-local
```

## License

MIT License - see [LICENSE](LICENSE) file.

## Support

- GitHub Issues: https://github.com/vsay/vsay-shell-cli/issues
- Documentation: https://docs.vsay.com
